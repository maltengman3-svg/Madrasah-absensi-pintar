
import React, { useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';

interface QRScannerProps {
  onScan: (decodedText: string) => void;
  isScanning: boolean;
}

const QRScanner: React.FC<QRScannerProps> = ({ onScan, isScanning }) => {
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    if (isScanning && !scannerRef.current) {
      const scanner = new Html5QrcodeScanner(
        "qr-reader",
        { fps: 10, qrbox: { width: 250, height: 250 } },
        /* verbose= */ false
      );

      scanner.render(
        (decodedText) => {
          onScan(decodedText);
          scanner.clear();
          scannerRef.current = null;
        },
        (error) => {
          // Keep scanning on error
        }
      );

      scannerRef.current = scanner;
    }

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(e => console.error(e));
        scannerRef.current = null;
      }
    };
  }, [isScanning, onScan]);

  return (
    <div className="w-full max-w-md mx-auto overflow-hidden rounded-2xl bg-white shadow-lg border border-slate-100">
      <div id="qr-reader" className="w-full"></div>
      {!isScanning && (
        <div className="p-8 text-center text-slate-500">
          Scanner tidak aktif
        </div>
      )}
    </div>
  );
};

export default QRScanner;
