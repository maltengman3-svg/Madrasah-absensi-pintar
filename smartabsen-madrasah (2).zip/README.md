
# 🏫 SmartAbsen Madrasah

Aplikasi absensi sekolah berbasis web dengan fitur QR Scanner, Validasi Lokasi (GPS), dan Analisis Kehadiran berbasis AI (Gemini).

## ✨ Fitur Utama
- **QR Scanner:** Absensi cepat menggunakan kamera HP.
- **Geofencing:** Memastikan siswa berada di area sekolah saat absen.
- **Smart AI:** Analisis pola kehadiran dan motivasi otomatis menggunakan Gemini AI.
- **Responsive:** Tampilan cantik di HP maupun Laptop.

## 🔑 Cara Memasukkan API Key
Aplikasi ini membutuhkan **API_KEY** dari Google Gemini agar fitur AI berfungsi. 
**Jangan masukkan kunci di dalam kode sumber!**

### Untuk Online (Vercel/Netlify):
1. Buka Dashboard Hosting Anda.
2. Cari menu **Settings > Environment Variables**.
3. Tambahkan variable baru:
   - **Key:** `API_KEY`
   - **Value:** `(Masukkan Kunci API Gemini Anda)`
4. Simpan dan Redeploy.

### Untuk Lokal (VS Code/Terminal):
1. Buat file bernama `.env` di folder root.
2. Tambahkan baris: `API_KEY=kunci_anda_disini`
3. Restart server pengembangan Anda.

## 🚀 Cara Onlinekan (Deploy)
1. **Push ke GitHub:** Upload semua file ke repositori GitHub Anda.
2. **Koneksikan ke Vercel:** Import repositori di Vercel.
3. **Set Environment Variable:** Masukkan `API_KEY` seperti instruksi di atas.
4. **Selesai:** Website siap digunakan!

## 🛠️ Teknologi
- React 19
- Tailwind CSS
- Gemini API (gemini-3-flash-preview)
- Lucide React & Recharts
