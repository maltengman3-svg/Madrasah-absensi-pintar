
import React, { useState, useEffect, useCallback } from 'react';
import { 
  QrCode, 
  History, 
  User as UserIcon, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp,
  BrainCircuit,
  LogOut,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { AttendanceRecord, User, LocationState } from './types';
import QRScanner from './components/QRScanner';
import { analyzeAttendance } from './services/geminiService';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const SCHOOL_LOCATION = { lat: -6.2088, lng: 106.8456 }; // Jakarta dummy coordinate
const MAX_DISTANCE_METERS = 500;

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'scan' | 'history' | 'profile' | 'ai'>('scan');
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [location, setLocation] = useState<LocationState>({ lat: null, lng: null, error: null, loading: false });
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanResult, setLastScanResult] = useState<{ success: boolean; message: string } | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Persistence
  useEffect(() => {
    const savedUser = localStorage.getItem('absen_user');
    const savedRecords = localStorage.getItem('absen_records');
    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedRecords) setRecords(JSON.parse(savedRecords));
  }, []);

  useEffect(() => {
    if (user) localStorage.setItem('absen_user', JSON.stringify(user));
    if (records.length > 0) localStorage.setItem('absen_records', JSON.stringify(records));
  }, [user, records]);

  const requestLocation = () => {
    setLocation(prev => ({ ...prev, loading: true }));
    if (!navigator.geolocation) {
      setLocation({ lat: null, lng: null, error: "Geolocation tidak didukung", loading: false });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude, error: null, loading: false });
      },
      (err) => {
        setLocation({ lat: null, lng: null, error: "Gagal mengambil lokasi: " + err.message, loading: false });
      }
    );
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // meters
  };

  const handleScan = useCallback((decodedText: string) => {
    if (!user || !location.lat) {
      setLastScanResult({ success: false, message: "Pastikan lokasi aktif" });
      setIsScanning(false);
      return;
    }

    // In a real app, decodedText would be a dynamic token from the server
    const distance = calculateDistance(location.lat, location.lng, SCHOOL_LOCATION.lat, SCHOOL_LOCATION.lng);
    
    // Simulate some logic
    const status = new Date().getHours() > 8 ? 'Terlambat' : 'Hadir';
    
    const newRecord: AttendanceRecord = {
      id: Math.random().toString(36).substr(2, 9),
      studentId: user.id,
      studentName: user.name,
      timestamp: new Date().toISOString(),
      location: { lat: location.lat, lng: location.lng },
      status: status,
      type: 'Masuk'
    };

    setRecords(prev => [newRecord, ...prev]);
    setLastScanResult({ success: true, message: `Absensi berhasil: ${status}` });
    setIsScanning(false);
  }, [user, location]);

  const handleAIAnalysis = async () => {
    if (!user || records.length === 0) return;
    setIsAnalyzing(true);
    const analysis = await analyzeAttendance(records, user.name);
    setAiAnalysis(analysis);
    setIsAnalyzing(false);
  };

  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const nisn = formData.get('nisn') as string;
    
    if (name && nisn) {
      setUser({
        id: 'std_' + Math.random().toString(36).substr(2, 5),
        name,
        nisn,
        role: 'Siswa',
        class: 'X-IPA-1'
      });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-md p-8 rounded-3xl shadow-xl border border-slate-100">
          <div className="flex justify-center mb-6">
            <div className="p-4 bg-emerald-50 rounded-2xl">
              <ShieldCheck className="w-12 h-12 text-emerald-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-center text-slate-900 mb-2">SmartAbsen Madrasah</h1>
          <p className="text-slate-500 text-center mb-8">Silakan login untuk mulai melakukan absensi</p>
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nama Lengkap</label>
              <input 
                name="name"
                required
                type="text" 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                placeholder="Masukkan nama Anda"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">NISN / ID Siswa</label>
              <input 
                name="nisn"
                required
                type="text" 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                placeholder="Masukkan NISN"
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200"
            >
              Masuk Sekarang
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24 lg:pb-0 lg:pl-64">
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex flex-col fixed inset-y-0 left-0 w-64 bg-white border-r border-slate-100 z-30">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 bg-emerald-600 rounded-lg">
              <QrCode className="text-white w-6 h-6" />
            </div>
            <span className="font-bold text-xl text-slate-900">SmartAbsen</span>
          </div>
          
          <nav className="space-y-1">
            <NavButton active={activeTab === 'scan'} onClick={() => setActiveTab('scan')} icon={<QrCode />} label="Scan QR" />
            <NavButton active={activeTab === 'history'} onClick={() => setActiveTab('history')} icon={<History />} label="Riwayat" />
            <NavButton active={activeTab === 'ai'} onClick={() => { setActiveTab('ai'); handleAIAnalysis(); }} icon={<BrainCircuit />} label="Smart AI" />
            <NavButton active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} icon={<UserIcon />} label="Profil" />
          </nav>
        </div>
        
        <div className="mt-auto p-6 border-t border-slate-100">
          <button 
            onClick={() => { localStorage.clear(); window.location.reload(); }}
            className="flex items-center gap-3 text-slate-500 hover:text-red-600 transition-colors w-full"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Keluar</span>
          </button>
        </div>
      </aside>

      {/* Header Mobile */}
      <header className="lg:hidden bg-white px-6 py-4 flex items-center justify-between border-b border-slate-100 sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-emerald-600 rounded-lg">
            <QrCode className="text-white w-5 h-5" />
          </div>
          <span className="font-bold text-lg text-slate-900">SmartAbsen</span>
        </div>
        <button 
           onClick={() => setActiveTab('profile')}
           className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center border-2 border-white shadow-sm overflow-hidden"
        >
          <img src={`https://picsum.photos/seed/${user.name}/200`} alt="Avatar" />
        </button>
      </header>

      {/* Main Content Area */}
      <main className="max-w-4xl mx-auto p-4 lg:p-8">
        
        {/* TAB: SCAN */}
        {activeTab === 'scan' && (
          <div className="space-y-6">
            <div className="bg-emerald-600 rounded-3xl p-8 text-white shadow-xl shadow-emerald-100">
              <h1 className="text-2xl font-bold mb-1">Assalamu'alaikum, {user.name.split(' ')[0]}!</h1>
              <p className="opacity-90">Jangan lupa berdoa sebelum mulai belajar.</p>
              
              <div className="mt-8 flex items-center gap-4 bg-emerald-500/30 p-4 rounded-2xl backdrop-blur-sm border border-emerald-400/20">
                <MapPin className="w-6 h-6 shrink-0" />
                <div className="flex-1">
                  <p className="text-sm font-medium opacity-80">Lokasi Anda Sekarang</p>
                  <p className="font-semibold truncate">
                    {location.lat ? `${location.lat.toFixed(4)}, ${location.lng?.toFixed(4)}` : location.loading ? "Mencari lokasi..." : "Belum terdeteksi"}
                  </p>
                </div>
                <button 
                  onClick={requestLocation}
                  className="bg-white text-emerald-600 px-4 py-2 rounded-xl text-sm font-bold active:scale-95 transition-transform"
                >
                  Update
                </button>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-md border border-slate-100">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Scan QR Code</h2>
                  <p className="text-sm text-slate-500">Scan QR dari layar monitor Guru Anda</p>
                </div>
                {isScanning ? (
                  <button onClick={() => setIsScanning(false)} className="text-red-600 text-sm font-semibold">Batal</button>
                ) : (
                  <button 
                    disabled={!location.lat}
                    onClick={() => setIsScanning(true)} 
                    className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-semibold shadow-lg shadow-emerald-100 disabled:opacity-50"
                  >
                    Mulai Scan
                  </button>
                )}
              </div>

              {isScanning ? (
                <QRScanner onScan={handleScan} isScanning={isScanning} />
              ) : lastScanResult ? (
                <div className={`p-6 rounded-2xl flex items-center gap-4 ${lastScanResult.success ? 'bg-emerald-50 border border-emerald-100' : 'bg-red-50 border border-red-100'}`}>
                  {lastScanResult.success ? <CheckCircle2 className="text-emerald-600 w-8 h-8" /> : <AlertCircle className="text-red-600 w-8 h-8" />}
                  <div>
                    <h3 className={`font-bold ${lastScanResult.success ? 'text-emerald-900' : 'text-red-900'}`}>
                      {lastScanResult.success ? 'Absensi Berhasil!' : 'Gagal Scan'}
                    </h3>
                    <p className={`text-sm ${lastScanResult.success ? 'text-emerald-700' : 'text-red-700'}`}>
                      {lastScanResult.message}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="border-2 border-dashed border-slate-100 rounded-3xl p-12 text-center">
                  <QrCode className="w-16 h-16 text-slate-200 mx-auto mb-4" />
                  <p className="text-slate-400">Klik "Mulai Scan" untuk menggunakan kamera</p>
                </div>
              )}
            </div>

            {/* Attendance Summary Mini Chart */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                <div className="p-3 bg-blue-50 w-fit rounded-xl mb-4">
                  <CheckCircle2 className="w-6 h-6 text-blue-600" />
                </div>
                <p className="text-sm text-slate-500 font-medium">Hadir Tepat Waktu</p>
                <p className="text-2xl font-bold text-slate-900">{records.filter(r => r.status === 'Hadir').length}</p>
              </div>
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                <div className="p-3 bg-orange-50 w-fit rounded-xl mb-4">
                  <AlertCircle className="w-6 h-6 text-orange-600" />
                </div>
                <p className="text-sm text-slate-500 font-medium">Terlambat</p>
                <p className="text-2xl font-bold text-slate-900">{records.filter(r => r.status === 'Terlambat').length}</p>
              </div>
            </div>
          </div>
        )}

        {/* TAB: HISTORY */}
        {activeTab === 'history' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900">Riwayat Absensi</h1>
            
            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
              {records.length > 0 ? (
                <div className="divide-y divide-slate-100">
                  {records.map((record) => (
                    <div key={record.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-2xl ${record.status === 'Hadir' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                          <History className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">{record.status}</p>
                          <p className="text-xs text-slate-500">{new Date(record.timestamp).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' })}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-300" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-12 text-center text-slate-400">
                   Belum ada data absensi.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB: AI ANALYSIS */}
        {activeTab === 'ai' && (
          <div className="space-y-6">
            <div className="bg-indigo-600 rounded-3xl p-8 text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-4">
                  <BrainCircuit className="w-8 h-8" />
                  <h1 className="text-2xl font-bold">Smart Analysis</h1>
                </div>
                <p className="opacity-90 max-w-md">Gemini AI akan menganalisis pola kehadiranmu dan memberikan saran belajar yang tepat.</p>
              </div>
              <BrainCircuit className="absolute -right-10 -bottom-10 w-64 h-64 opacity-10 rotate-12" />
            </div>

            {isAnalyzing ? (
              <div className="bg-white rounded-3xl p-12 text-center shadow-md border border-slate-100">
                <div className="animate-spin w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-slate-600 font-medium">AI sedang menganalisis data absensi...</p>
              </div>
            ) : aiAnalysis ? (
              <div className="space-y-6">
                <div className="bg-white rounded-3xl p-8 shadow-md border border-slate-100">
                  <div className="flex items-center gap-2 mb-4 text-indigo-600">
                    <TrendingUp className="w-5 h-5" />
                    <span className="font-bold uppercase tracking-wider text-sm">Kesimpulan AI</span>
                  </div>
                  <p className="text-slate-700 leading-relaxed text-lg italic">"{aiAnalysis.summary}"</p>
                  
                  <div className="mt-8 grid grid-cols-2 gap-6">
                    <div className="bg-slate-50 p-6 rounded-2xl">
                      <p className="text-sm text-slate-500 mb-1">Tingkat Kehadiran</p>
                      <p className="text-3xl font-bold text-slate-900">{aiAnalysis.stats.attendanceRate}%</p>
                    </div>
                    <div className="bg-slate-50 p-6 rounded-2xl">
                      <p className="text-sm text-slate-500 mb-1">Jumlah Terlambat</p>
                      <p className="text-3xl font-bold text-slate-900">{aiAnalysis.stats.lateCount}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-emerald-50 border border-emerald-100 rounded-3xl p-8">
                  <h3 className="font-bold text-emerald-900 mb-2 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5" /> Saran Guru Pintar
                  </h3>
                  <p className="text-emerald-800 leading-relaxed">{aiAnalysis.advice}</p>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-12 text-center shadow-md border border-slate-100">
                 <button 
                  onClick={handleAIAnalysis}
                  className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100 hover:scale-105 transition-transform"
                 >
                   Dapatkan Analisis AI
                 </button>
              </div>
            )}
          </div>
        )}

        {/* TAB: PROFILE */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8 text-center">
              <div className="relative inline-block mb-4">
                <img 
                  src={`https://picsum.photos/seed/${user.name}/300`} 
                  alt="Profile" 
                  className="w-32 h-32 rounded-full border-4 border-emerald-50 shadow-md"
                />
                <div className="absolute bottom-1 right-1 bg-emerald-600 text-white p-2 rounded-full border-2 border-white">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>
              <h2 className="text-2xl font-bold text-slate-900">{user.name}</h2>
              <p className="text-slate-500 font-medium">{user.class} • {user.nisn}</p>
              
              <div className="mt-8 pt-8 border-t border-slate-100 grid grid-cols-3 gap-4">
                <div>
                  <p className="text-2xl font-bold text-slate-900">{records.length}</p>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">Total Absen</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">98%</p>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">Disiplin</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">A+</p>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">Predikat</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
              <div className="p-6 border-b border-slate-50">
                <h3 className="font-bold text-slate-900">Pengaturan Akun</h3>
              </div>
              <div className="divide-y divide-slate-100">
                <ProfileItem icon={<UserIcon className="text-blue-500"/>} label="Edit Profil" />
                <ProfileItem icon={<MapPin className="text-red-500"/>} label="Lokasi Sekolah" />
                <ProfileItem icon={<History className="text-emerald-500"/>} label="Riwayat Lengkap" />
                <button 
                   onClick={() => { localStorage.clear(); window.location.reload(); }}
                   className="w-full p-4 flex items-center justify-between text-red-600 hover:bg-red-50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <LogOut className="w-5 h-5" />
                    <span className="font-bold">Keluar Akun</span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Navigation Mobile */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-6 py-3 flex items-center justify-between z-30 shadow-[0_-4px_12px_rgba(0,0,0,0.05)]">
        <NavIconButton active={activeTab === 'scan'} onClick={() => setActiveTab('scan')} icon={<QrCode />} />
        <NavIconButton active={activeTab === 'history'} onClick={() => setActiveTab('history')} icon={<History />} />
        <div className="relative -top-8">
           <button 
              onClick={() => { setActiveTab('ai'); handleAIAnalysis(); }}
              className={`p-5 rounded-full shadow-lg transition-all ${activeTab === 'ai' ? 'bg-indigo-600 text-white scale-110' : 'bg-white text-slate-400 border border-slate-100'}`}
           >
             <BrainCircuit />
           </button>
        </div>
        <NavIconButton active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} icon={<UserIcon />} />
        <NavIconButton active={false} onClick={() => {}} icon={<History />} /> {/* Placeholder to maintain spacing */}
      </nav>
    </div>
  );
};

// UI Helper Components
const NavButton = ({ active, onClick, icon, label }: any) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all ${active ? 'bg-emerald-50 text-emerald-700' : 'text-slate-500 hover:bg-slate-50'}`}
  >
    {React.cloneElement(icon, { className: 'w-5 h-5' })}
    <span>{label}</span>
  </button>
);

const NavIconButton = ({ active, onClick, icon }: any) => (
  <button 
    onClick={onClick}
    className={`p-2 rounded-xl transition-all ${active ? 'text-emerald-600' : 'text-slate-400'}`}
  >
    {React.cloneElement(icon, { className: 'w-6 h-6' })}
  </button>
);

const ProfileItem = ({ icon, label }: any) => (
  <button className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors group">
    <div className="flex items-center gap-4">
      {icon}
      <span className="font-semibold text-slate-700">{label}</span>
    </div>
    <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-slate-500 transition-colors" />
  </button>
);

export default App;
