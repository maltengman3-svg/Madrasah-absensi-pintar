
import { GoogleGenAI, Type } from "@google/genai";
import { AttendanceRecord } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeAttendance = async (records: AttendanceRecord[], userName: string) => {
  const prompt = `
    Analisis data absensi berikut untuk siswa bernama ${userName}:
    ${JSON.stringify(records)}
    
    Berikan ringkasan dalam bahasa Indonesia yang ramah dan memotivasi. 
    Tujuannya adalah membantu siswa memahami pola kehadirannya dan memberikan saran jika sering terlambat.
    Berikan output dalam format JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING, description: "Ringkasan statistik kehadiran" },
            advice: { type: Type.STRING, description: "Saran motivasi atau perbaikan" },
            stats: { 
              type: Type.OBJECT, 
              properties: {
                attendanceRate: { type: Type.NUMBER },
                lateCount: { type: Type.NUMBER }
              },
              required: ["attendanceRate", "lateCount"]
            }
          },
          required: ["summary", "advice", "stats"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return null;
  }
};
