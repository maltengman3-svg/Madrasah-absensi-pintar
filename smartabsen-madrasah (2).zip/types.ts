
export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  timestamp: string;
  location: {
    lat: number;
    lng: number;
  };
  status: 'Hadir' | 'Terlambat' | 'Izin' | 'Sakit';
  type: 'Masuk' | 'Pulang';
}

export interface User {
  id: string;
  name: string;
  role: 'Siswa' | 'Guru' | 'Admin';
  nisn?: string;
  class?: string;
}

export interface LocationState {
  lat: number | null;
  lng: number | null;
  error: string | null;
  loading: boolean;
}
